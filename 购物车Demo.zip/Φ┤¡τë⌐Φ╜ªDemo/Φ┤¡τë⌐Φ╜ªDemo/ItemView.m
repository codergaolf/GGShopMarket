//
//  ItemView.m
//  购物车Demo
//
//  Created by 高立发 on 2016/10/11.
//  Copyright © 2016年 fanyang. All rights reserved.
//

#import "ItemView.h"

@interface ItemView()
@property (nonatomic, strong, readwrite) NSMutableArray *buttonArr;

@end

@implementation ItemView

- (instancetype) initWithDataDictionry: (NSDictionary *)dataDic {
    self = [super init];
    if (!self) {
        return nil;
    }
    
//    self.backgroundColor = somecolor
    
    _isSelected = NO;
    _buttonArr = [[NSMutableArray alloc]init];
    //数据字典
    _dataDic = dataDic;
    
    _titleLb = [[UILabel alloc]init];
    _titleLb.text = _dataDic[@"name"];
//    _titleLb.textColor = somecolor;
    [self addSubview:_titleLb];
    
    [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.equalTo(self).with.offset(10);
    }];
    
    //数据数组
    NSArray *dataArr = _dataDic[@"speclist"];
    
    CGFloat w = 0;//保存前一个button的宽以及前一个button距离屏幕边缘的距离
    CGFloat h = 50;//用来控制button距离父视图的高
    CGFloat screenWidth = [[UIScreen mainScreen]bounds].size.width;
    for (int i = 0; i < dataArr.count; i++) {
        
        NSDictionary *detailDic = dataArr[i];
        NSString *title = detailDic[@"value"];
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.tag = 100 + i;
        button.backgroundColor = [UIColor whiteColor];
        
//        if (i == 0) {
//            [button setBackgroundColor:[UIColor orangeColor]];
//            button.selected = YES;
//        }
        
        button.layer.cornerRadius = 11;
        button.layer.masksToBounds = YES;
        button.layer.borderWidth = 2.0;
        button.layer.borderColor = [[UIColor lightGrayColor] CGColor];
        
        [button addTarget:self action:@selector(handleClick:) forControlEvents:UIControlEventTouchUpInside];
        [button setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        //根据计算文字的大小
        
        button.titleLabel.font = [UIFont systemFontOfSize:14.0];
        NSDictionary *attributes = @{NSFontAttributeName:[UIFont systemFontOfSize:14.0]};
        CGFloat length = [title boundingRectWithSize:CGSizeMake(screenWidth, 2000) options:NSStringDrawingUsesLineFragmentOrigin attributes:attributes context:nil].size.width;
        //为button赋值
        [button setTitle:title forState:UIControlStateNormal];
        //设置button的frame
        button.frame = CGRectMake(10 + w, h, length + 20 , 22);
        //当button的位置超出屏幕边缘时换行 320 只是button所在父视图的宽度
        if(10 + w + length + 15 > screenWidth){
            w = 0; //换行时将w置为0
            h = h + button.frame.size.height + 10;//距离父视图也变化
            button.frame = CGRectMake(10 + w, h, length + 20, 22);//重设button的frame
        }
        w = button.frame.size.width + button.frame.origin.x;
        [self addSubview:button];
        
        [self.buttonArr addObject:button];
        self.height = CGRectGetMaxY(button.frame) + 10;
    }

    
    
    return self;
}

//点击事件
- (void)handleClick:(UIButton *)btn{
    
    _isSelected = YES;
    
    //数据数组
    NSArray *dataArr = _dataDic[@"speclist"];

    
    for (UIButton *b in self.buttonArr) {
        if (b == btn) {
            
            NSDictionary *selectDic = [dataArr objectAtIndex:[self.buttonArr indexOfObject:b]];
            _selectedDic = selectDic;
            
//            [b setBackgroundColor:[UIColor orangeColor]];
            b.layer.borderColor = [[UIColor redColor] CGColor];;
            [b setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
            
            if (b.selected == NO) {
                if (_selected) {
                    _selected(selectDic);
                }
                b.selected = YES;
            } else {
                //已经选中了, 就什么也别做
            }
            
        } else {
            b.layer.borderColor = [[UIColor lightGrayColor] CGColor];;
            [b setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            b.selected = NO;

            
        }
    }
//    NSLog(@"%ld",btn.tag);
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
