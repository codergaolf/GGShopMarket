//
//  ShopViewController.m
//  购物车Demo
//
//  Created by 高立发 on 2016/10/9.
//  Copyright © 2016年 fanyang. All rights reserved.
//



#import "ShopViewController.h"

#import "Store.h"
#import "StoreGoodInfo.h"

#import "GoodTableViewCell.h"

@interface ShopViewController ()
<
UITableViewDataSource,
UITableViewDelegate
>
{
    UIView *bottomView;
}
//**  token */
@property(nonatomic,copy)NSString * token;

//**  dataDic */
@property (nonatomic, strong) NSDictionary *dataDic;

//**  分段的数组 */
@property (nonatomic, strong) NSMutableArray *storeArray;

//**  创建cell的数据源 */
@property (nonatomic, strong) NSMutableArray *dataArray;

//**  tableView */
@property (nonatomic, strong) UITableView *tableView;

//**  结算金额 */
@property (nonatomic, assign) CGFloat totalPrice;
//**  总价展示 */
@property (nonatomic, strong) UILabel *totalPriceLb;

//**  全选状态 */
@property (nonatomic, assign) BOOL isAllSelected;
//**  全选按钮 */
@property (nonatomic, strong) UIButton *selectAllBtn;

//**  支付按钮 */
@property (nonatomic, strong) UIButton *payBtn;


@end

@implementation ShopViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.dataArray = [[NSMutableArray alloc]init];
    _totalPrice = 0.0;
    
//    self.view.backgroundColor = somecolor
    
    //创建UI
    [self creatUI];
    
    //请求数据
    [self loadData];
}

#pragma mark =============== 画UI ===============
- (void) creatUI {
    
    UIBarButtonItem *rightBarItem = [[UIBarButtonItem alloc]initWithTitle:@"reloadData" style:UIBarButtonItemStyleDone target:self action:@selector(reDownloadData)];
    self.navigationItem.rightBarButtonItem = rightBarItem;
    
    //tableView
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, Screen_Width, Screen_Height - 49) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.userInteractionEnabled=YES;
    _tableView.dataSource = self;
    _tableView.scrollsToTop=YES;
    _tableView.bounces = NO;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
//    _tableView.backgroundColor = somecolor
    [self.view addSubview: _tableView];
    
    
    //下面的工具栏
    bottomView = [[UIView alloc]initWithFrame:CGRectMake(0, Screen_Height - 49-49, Screen_Width, 49)];
    bottomView.backgroundColor = [UIColor whiteColor];

    //圈圈按钮
    _selectAllBtn = [self creatBtn:@selector(selectSection:)];
    _selectAllBtn.tag = 100;
    
    //合计
    UILabel *totalLb = [[UILabel alloc]init];
    totalLb.text = @"合计:";
    
    //总价格
    _totalPriceLb = [[UILabel alloc]init];
    _totalPriceLb.textColor = [UIColor redColor];
    _totalPriceLb.text = [NSString stringWithFormat:@"¥%.2f",_totalPrice];
    
    //删除按钮
    UIButton *deleteBtn = [UIButton buttonWithType: UIButtonTypeCustom];
    deleteBtn.titleLabel.font = [UIFont systemFontOfSize:15.0];
    [deleteBtn setTitle:@"删除" forState:UIControlStateNormal];
    [deleteBtn setBackgroundColor:[UIColor orangeColor]];
    [deleteBtn addTarget:self action:@selector(deleteItems:) forControlEvents: UIControlEventTouchUpInside];
    
    //结算按钮
    _payBtn = [UIButton buttonWithType: UIButtonTypeCustom];
    _payBtn.titleLabel.font = [UIFont systemFontOfSize:15.0];
    [_payBtn setTitle:@"去支付(0)" forState:UIControlStateNormal];
    [_payBtn setBackgroundColor:[UIColor redColor]];
    [_payBtn addTarget:self action:@selector(payAction:) forControlEvents: UIControlEventTouchUpInside];
    
    
    [bottomView addSubview: _selectAllBtn];
    [bottomView addSubview: totalLb];
    [bottomView addSubview: _totalPriceLb];
    [bottomView addSubview: deleteBtn];
    [bottomView addSubview: _payBtn];
    
    [self.view addSubview: bottomView];
    
    //约束
    [_selectAllBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(bottomView);
        make.left.equalTo(bottomView).with.offset(10);
        make.width.height.equalTo(@(20));
    }];
    
    [totalLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_selectAllBtn.mas_right).with.offset(10);
        make.top.bottom.equalTo(bottomView);
    }];
    
    [_totalPriceLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(totalLb.mas_right).with.offset(5);
        make.top.bottom.equalTo(bottomView);
    }];
    
    [_payBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(bottomView);
        make.top.bottom.equalTo(bottomView);
        make.width.equalTo(@(80));
    }];
    
    [deleteBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(_payBtn.mas_left);
        make.top.bottom.equalTo(bottomView);
        make.width.equalTo(@(80));
    }];
    
}

//创建圈圈按钮
- (UIButton *) creatBtn: (SEL) selectSec {
    //圆圈按钮
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.layer.masksToBounds = YES;
    btn.layer.cornerRadius = 10.0;
    btn.layer.borderWidth = 2.0;
    btn.layer.borderColor = [[UIColor grayColor]CGColor];
    [btn setBackgroundColor:[UIColor whiteColor]];
    [btn addTarget:self action:selectSec forControlEvents:UIControlEventTouchUpInside];
    return btn;
}

#pragma mark =============== UITableViewDataSource ===============
- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
    return  self.dataArray.count;
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.dataArray[section] count];
}

- (CGFloat) tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 40;
}

- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 120;
}

#pragma mark =============== UITableVIewDelegate ===============
- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSInteger section = indexPath.section;
    NSInteger row = indexPath.row;
    StoreGoodInfo *goodInfo = self.dataArray[section][row];
    
    static NSString *cellID = @"cellID";
    GoodTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[GoodTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    
    //这个点击事件需要刷新整段的UI
    cell.btClick = ^(){
        goodInfo.isSelected = !goodInfo.isSelected;
        
        NSIndexSet *indexSet = [NSIndexSet indexSetWithIndex:section];
        [self.tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationNone];
        
        NSLog(@"段: %ld, 行: %ld, 选中状态: %d", (long)section, (long)row, goodInfo.isSelected);
        
        //查看下全部的状态
        [self checkAllStatus];
    };
    
    cell.goodInfo = goodInfo;
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}

- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
    Store *store = self.storeArray[section];
    
    //段头视图
    UIView *headerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, Screen_Width, 40)];
//    headerView.backgroundColor = somecolor
    headerView.backgroundColor = [UIColor whiteColor];
    headerView.userInteractionEnabled = YES;
    headerView.tag = 10000+section;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(pushToStore:)];
    [headerView addGestureRecognizer:tap];
    
    //圆圈按钮
    UIButton *btn = [self creatBtn:@selector(selectSection:)];
    btn.tag = 1000 + section;
    btn.frame = CGRectMake(10, 10, 20, 20);
    
    store.isSelected = YES;
    for (StoreGoodInfo *goodInfo in self.dataArray[section]) {
        if (goodInfo.isSelected == NO) {
            store.isSelected = NO;
            break;
        }
    }
    
    if (store.isSelected == YES) {
        [btn setBackgroundColor: [UIColor redColor]];
    } else {
        [btn setBackgroundColor: [UIColor whiteColor]];
    }
    
    
    //店铺图标
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(50, 5, 30, 30)];
    [imageView sd_setImageWithURL:[NSURL URLWithString:@"http://e.hiphotos.baidu.com/image/pic/item/14ce36d3d539b600be63e95eed50352ac75cb7ae.jpg"]];
    
    //店铺名称
    UILabel *titleLb = [[UILabel alloc]initWithFrame: CGRectMake(90, 0, Screen_Width - 140, 40)];
    titleLb.textColor = [UIColor blackColor];
    titleLb.text = store.store_name;
    
    //右边箭头
    UIImageView *rightImageView = [[UIImageView alloc]initWithFrame:CGRectMake(Screen_Width - 50, 5, 30, 30)];
    [rightImageView sd_setImageWithURL:[NSURL URLWithString:@"http://f.hiphotos.baidu.com/image/pic/item/242dd42a2834349b7eaf886ccdea15ce37d3beaa.jpg"]];
    
    [headerView addSubview:btn];
    [headerView addSubview:imageView];
    [headerView addSubview:titleLb];
    [headerView addSubview:rightImageView];
    
    return headerView;
    
}

- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    StoreGoodInfo *goodInfo = self.dataArray[indexPath.section][indexPath.row];
    NSLog(@"\n商品id: %@\n名字: %@\n单价: %@",goodInfo.goods_id, goodInfo.goods_name, goodInfo.goods_price);
}

#pragma mark =============== Action ===============

//重新加载数据
- (void) reDownloadData {
    [self loadData];
}

//选择
- (void) selectSection: (UIButton *)btn
{
    //改变选中状态
    btn.selected = !btn.selected;
    
    //调整UI
    if (btn.selected == YES) {
        [btn setBackgroundColor: [UIColor redColor]];
    } else {
        [btn setBackgroundColor: [UIColor whiteColor]];
    }
    
    //全选
    if (btn.tag < 1000) {
        NSLog(@"全选");
        
        _isAllSelected = !_isAllSelected;
        
        //说明要全选, 那么就把没选的都选上
        if (_isAllSelected == YES) {
            for (NSArray *smallArray in self.dataArray) {
                for (StoreGoodInfo *goodInfo in smallArray) {
                    if (goodInfo.isSelected == YES) {
                        
                    } else {
                        goodInfo.isSelected = YES;
                    }
                }
            }
        }
        
        //取消全选, 把选中的取消
        else {
            for (NSArray *smallArray in self.dataArray) {
                for (StoreGoodInfo *goodInfo in smallArray) {
                    if (goodInfo.isSelected == YES) {
                        goodInfo.isSelected = NO;
                    } else {
                        
                    }
                }
            }
        }
        
        //tableView刷新一下
        [self.tableView reloadData];
        
        //检查一下, 刷新一下底部的数据
        [self checkAllStatus];
    }
    
    //选一段
    else if (btn.tag >= 1000 && btn.tag < 2000) {
        
        NSInteger section = btn.tag - 1000;
        NSLog(@"选一段%ld",section);
        
        //获取到段头的model
        Store *store = self.storeArray[section];
        //改变状态
        store.isSelected = !store.isSelected;
        
        //拿到对应创建cell的小数组
        NSArray *smallArray = self.dataArray[section];
        
        
        //根据store的状态改变cell的状态
        
        if (store.isSelected) {
            //遍历改变状态
            for (StoreGoodInfo *goodInfo in smallArray) {
                
                if (goodInfo.isSelected == YES) {
                    
                } else {
                    goodInfo.isSelected = YES;
                }
            }
        } else {
            //遍历改变状态
            for (StoreGoodInfo *goodInfo in smallArray) {
                
                if (goodInfo.isSelected == YES) {
                    goodInfo.isSelected = NO;
                } else {
                    
                }
            }
        }
        
        //刷一下对应的段
        NSIndexSet *indexSet = [NSIndexSet indexSetWithIndex:section];
        [self.tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationNone];
        
        //查看一下所有的
        [self checkAllStatus];
        
    }
    
}

//检查下所有的商品状态
- (void) checkAllStatus
{
    
    //先默认全选状态是yes, 如果goodInfo有no的话, 就改回no
    //如果数组是空的就默认是 no
    if (self.dataArray.count == 0) {
        _isAllSelected = NO;
    } else {
        _isAllSelected = YES;
    }
    
    //每次进来检查的时候可以先把价格归零重算
    _totalPrice = 0.0;
    
    //结算总数
    NSUInteger payCount = 0;
    
    //全都看一下, 如果都选了那全选的UI也对应上
    for (NSArray *smallArray in self.dataArray) {
        for (StoreGoodInfo *goodInfo in smallArray) {
            
            //单价和数量
            CGFloat singlePrice = [goodInfo.goods_price integerValue];
            NSUInteger count = [goodInfo.goods_num integerValue];
            
            if (goodInfo.isSelected == NO) {
                [_selectAllBtn setBackgroundColor:[UIColor whiteColor]];
                _isAllSelected = NO;
            } else {
                payCount++;
                _totalPrice += singlePrice * count;
            }
        }
    }
    
    //前边都过完之后看下是否全选了, 对应给全选按钮改变状态
    if (_isAllSelected == YES) {
        [_selectAllBtn setBackgroundColor:[UIColor redColor]];
    } else {
        [_selectAllBtn setBackgroundColor:[UIColor whiteColor]];
    }
    
    
    //最后把价格刷一下吧
    _totalPriceLb.text = [NSString stringWithFormat:@"¥%.2f",_totalPrice];
    //刷支付数量
    [_payBtn setTitle:[NSString stringWithFormat:@"去支付(%lu)",(unsigned long)payCount] forState:UIControlStateNormal];
    
}

//跳到店铺
- (void) pushToStore: (UITapGestureRecognizer *)tap
{
    UIView *headerView = tap.view;
    NSUInteger section = headerView.tag - 10000;
    Store *store = self.storeArray[section];
    
    NSLog(@"\n店铺name: %@\n店铺id: %@",store.store_name, store.store_id);
}


//删除
- (void) deleteItems: (UIButton *)deleBtn
{
    NSLog(@"删除");
    //全都看一下, 如果都选了那全选的UI也对应上
    
    //cell数组对应数据删除
    NSMutableArray *deleteIdArray = [[NSMutableArray alloc]init];
    for (NSMutableArray *smallArray in self.dataArray) {
        
        //需要删掉的都放到这个数组里面
        NSMutableArray *deleteArray = [[NSMutableArray alloc]init];
        for (StoreGoodInfo *goodInfo in smallArray) {
            if (goodInfo.isSelected == YES) {
                [deleteArray addObject:goodInfo];
                [deleteIdArray addObject:goodInfo.goods_id];
            } else {
                
            }
        }
        
        //如果数组里面有东西, 就对应删除smallArray里面创建cell的model
        if (deleteArray.count > 0) {
            for (StoreGoodInfo *deleteItem in deleteArray) {
                [smallArray removeObject:deleteItem];
            }
        }
    }
    
    NSLog(@"\n\n删除的good_id:\n%@",[deleteIdArray componentsJoinedByString:@","]);
    
    
    //section对应数据删除 主要是看下, 是不是某一个组被删完了, 对应删一下它的段头对应的数据和 对应dataArray里面的空数组
    
    //待删的都放到这个数组
    NSMutableArray *deleteArray = [[NSMutableArray alloc]init];
    
    //遍历dataArray
    for (NSMutableArray *smallArray in self.dataArray) {
        if (smallArray.count == 0) {
            
            NSUInteger index = [self.dataArray indexOfObject:smallArray];
            
            //删除段头对应的model
            [self.storeArray removeObjectAtIndex:index];
            [deleteArray addObject:smallArray];
        }
    }
    
    //如果待删数组里面有东西, 遍历一下从dataArray里面删除掉
    if (deleteArray.count > 0) {
        for (NSMutableArray *deleteSectionArray in deleteArray) {
            [self.dataArray removeObject:deleteSectionArray];
        }
        
    }
    
    //刷新一下tableView和下面总价格那些的UI
    [self.tableView reloadData];
    [self checkAllStatus];
}

//支付
- (void) payAction: (UIButton *)payBtn
{
    
    NSLog(@"支付");
    
    if (_totalPrice == 0.00) {
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"请先选择产品" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alertView show];
        return;
    }
    
    //把所有选中的放到数组里面
    NSMutableArray *idArray = [[NSMutableArray alloc]init];
    for (NSMutableArray *smallArray in self.dataArray) {
        for (StoreGoodInfo *goodInfo in smallArray) {
            if (goodInfo.isSelected == YES) {
                [idArray addObject: goodInfo.goods_id];
            }
        }
    }
    
    NSString *idString = [idArray componentsJoinedByString:@","];
    
    NSLog(@"\n\n支付产品的id有这些:\n%@\n\n总价格为: %.2f",idString, _totalPrice);
    
}


#pragma mark =============== 获取数据 ===============
-(void)loadData{
    
#pragma mark  -- 本地获取数据
    //标准的字典格式
//    NSDictionary *rootDic = [NSKeyedUnarchiver unarchiveObjectWithFile:@"/Users/GLF/Desktop/购物车/购物车Demo/market.plist"];
    
    NSString *path = [[NSBundle mainBundle] pathForResource:@"market" ofType:@"plist"];
    NSDictionary *rootDic = [NSKeyedUnarchiver unarchiveObjectWithFile:path];

    
    NSDictionary *dataDic = rootDic[@"data"];
    
    //在这里拿到了创建section段头的数组
    _storeArray = [Store mj_objectArrayWithKeyValuesArray: dataDic[@"cart_list"]];
    
    //在这里拿到了用于创建cell的二维数组
    for (Store *store in _storeArray) {
        NSMutableArray *smallArray = [[NSMutableArray alloc]init];
        smallArray = [StoreGoodInfo mj_objectArrayWithKeyValuesArray: store.goodslist];
        [self.dataArray addObject:smallArray];
    }
    
    NSLog(@"dataArray-%@", _dataArray);
    
    [_tableView reloadData];
    
   
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
