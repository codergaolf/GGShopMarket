//
//  BottomView.m
//  购物车Demo
//
//  Created by 高立发 on 2016/10/11.
//  Copyright © 2016年 fanyang. All rights reserved.
//

#import "BottomView.h"

@implementation BottomView

-(instancetype)init {
    self = [super init];
    if (!self) {
        return nil;
    }
    
    self.backgroundColor = [UIColor whiteColor];
    
    _itemsArr = [[NSMutableArray alloc]init];
    _count = @"1";
    
    //**  图标 */
    _imageView = [[UIImageView alloc]init];
    [self addSubview:_imageView];
    
    //**  价格 */
    _priceLb = [[UILabel alloc]init];
    _priceLb.textColor = [UIColor redColor];
    [self addSubview:_priceLb];
    
    //**  库存 */
    _inventoryLb = [[UILabel alloc]init];
    _inventoryLb.font = [UIFont systemFontOfSize:15.0];
    [self addSubview:_inventoryLb];
    
    //**  描述 */
    _descLb = [[UILabel alloc]init];
    _descLb.font = [UIFont systemFontOfSize:15.0];
    [self addSubview:_descLb];
    
    //**  数量("购买数量") */
    _countLb = [[UILabel alloc]init];
    _countLb.text = @"购买数量";
    [self addSubview:_countLb];
    
    //**  取消 */
    _cancelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _cancelBtn.layer.masksToBounds = YES;
    _cancelBtn.layer.cornerRadius = 10.0;
    [_cancelBtn setTitle:@"X" forState:UIControlStateNormal];
    [_cancelBtn setBackgroundColor:[UIColor colorWithRed:0.5 green:0.5 blue:0.5 alpha:1.0]];
    [_cancelBtn addTarget:self action:@selector(cancelBuy) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_cancelBtn];
    
    //**  购买数量 */
    _buyCount = [[UILabel alloc]init];
    _buyCount.text = _count;
    [self addSubview:_buyCount];
    
    //**  减少 */
    _minusBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _minusBtn.layer.masksToBounds = YES;
    _minusBtn.layer.cornerRadius = 10.0;
    [_minusBtn setTitle:@"-" forState:UIControlStateNormal];
    [_minusBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_minusBtn setBackgroundColor:[UIColor orangeColor]];
    [_minusBtn addTarget:self action:@selector(minus) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_minusBtn];
    
    //**  增加 */
    _plusBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _plusBtn.layer.masksToBounds = YES;
    _plusBtn.layer.cornerRadius = 10.0;
    [_plusBtn setTitle:@"+" forState:UIControlStateNormal];
    [_plusBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_plusBtn setBackgroundColor:[UIColor orangeColor]];
    [_plusBtn addTarget:self action:@selector(plus) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_plusBtn];
    
    //**  加入购物车 */
    _marketBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [_marketBtn setTitle:@"加入购物车" forState:UIControlStateNormal];
    [_marketBtn setBackgroundColor:[UIColor redColor]];
    [_marketBtn addTarget:self action:@selector(addInMarket) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_marketBtn];
    
//    for (UIView *view in self.subviews) {
//        view.backgroundColor = somecolor
//    }
    
    return self;
}

- (void) layoutSubviews {
    
    [_imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.equalTo(self).with.offset(10);
        make.width.height.equalTo(@(60));
    }];
    
    [_priceLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_imageView);
        make.left.equalTo(_imageView.mas_right).with.offset(10);
        make.height.equalTo(@(20));
    }];
    
    [_inventoryLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_priceLb.mas_bottom);
        make.left.height.equalTo(_priceLb);
    }];
    
    [_descLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_inventoryLb.mas_bottom).with.offset(5);
        make.left.equalTo(_priceLb);
        make.height.equalTo(_priceLb);
    }];
    
    [_cancelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).with.offset(15);
        make.right.equalTo(self).with.offset(-15);
        make.width.height.equalTo(@(20));
    }];
    
    [_marketBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).with.offset(10);
        make.right.equalTo(self).with.offset(-10);
        make.bottom.equalTo(self);
        make.height.equalTo(@(40));
    }];
    
    [_countLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(_marketBtn.mas_top).with.offset(-5);
        make.left.equalTo(_marketBtn);
        make.height.equalTo(@(30));
    }];
    
    [_plusBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(_marketBtn);
        make.bottom.equalTo(_marketBtn.mas_top).with.offset(-5);
        make.width.height.equalTo(@(30));
    }];
    
    [_buyCount mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(_plusBtn.mas_left).with.offset(-5);
        make.centerY.equalTo(_plusBtn);
    }];
    
    [_minusBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(_buyCount.mas_left).with.offset(-5);
        make.bottom.height.width.equalTo(_plusBtn);
    }];
    
    
    
}

#pragma mark =============== Data ===============

//库存
- (void) setGoods_storage:(NSString *)goods_storage
{
    _goods_storage = goods_storage;
    _inventoryLb.text = [NSString stringWithFormat:@"库存%@件",goods_storage];
}

//给产品价格
- (void) setPrice:(NSString *)price {
    _price = price;
    _singlePrice = [price floatValue];
    _priceLb.text = [NSString stringWithFormat:@"¥ %@",price];
}

- (void) setSpecInfoArray:(NSArray *)specInfoArray {
    _specInfoArray = specInfoArray;
    
    
    
    _scrollView = [[UIScrollView alloc]init];
//    _scrollView.backgroundColor = somecolor
    
    CGFloat h = 0;
    
    NSMutableString *descStr = [NSMutableString string];
    
    for (int i = 0; i < _specInfoArray.count; i++) {
        
        
        NSDictionary *itemDic = _specInfoArray[i];
        
        [descStr appendString:[NSString stringWithFormat:@" %@", itemDic[@"name"]]];
        
        ItemView *item1 = [[ItemView alloc]initWithDataDictionry: itemDic];
        
        item1.frame = CGRectMake(0, h, Screen_Width, item1.height);
        
        h = h + item1.height;
        
        item1.selected = ^(NSDictionary *dic){
            
            if (_selectBlock) {
                _selectBlock(dic);
            }
            NSLog(@"选中那个那个最小字典数据--%@", dic);
        };
        
        //加到scrollView上
        [_scrollView addSubview: item1];
        
        //加到数组里面到vc里面用
        [_itemsArr addObject:item1];
        
    }
    _scrollView.contentSize = CGSizeMake(Screen_Width, h);
    
    _descLb.text = [NSString stringWithFormat:@"请选择 %@", descStr];
    
    [self addSubview:_scrollView];
    
    [_scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_imageView.mas_bottom);
        make.left.right.equalTo(self);
        make.bottom.equalTo(_countLb.mas_top);
    }];
    
}

#pragma mark =============== Action ===============
//取消
- (void) cancelBuy {
    NSLog(@"取消");
    if (_cancel) {
        _cancel();
    }
}

//减一
- (void) minus {
    NSLog(@"较少");
    
    NSUInteger count = [_count integerValue];
    
    if (count == 1) return;
    
    count--;
    
    //数量对应
    _count = [NSString stringWithFormat:@"%lu", count];
    _buyCount.text = [NSString stringWithFormat:@"%lu", (unsigned long)count];
    
    //价格对应
    CGFloat totalPrice = _singlePrice * count;
    _price = [NSString stringWithFormat:@"%.2f", totalPrice];
    
    _priceLb.text = [NSString stringWithFormat:@"¥ %@",_price];
    
}

//加一
- (void) plus {
    NSLog(@"添加");
    
    //现有的
    NSUInteger count = [_count integerValue];
    //库存的
    NSUInteger inventoryCount = [_goods_storage integerValue];
    
    if (count == inventoryCount) {
        //如果都敢上库存了,就提示出来
        if (_alert) {
            _alert(@"所选数量超过库存");
        }
        return;
    }
    
    
    count++;
    
    //数量对应
    _count = [NSString stringWithFormat:@"%lu", count];
    _buyCount.text = [NSString stringWithFormat:@"%lu", (unsigned long)count];
    
    //价格对应
    CGFloat totalPrice = _singlePrice * count;
    _price = [NSString stringWithFormat:@"%.2f", totalPrice];
    
    _priceLb.text = [NSString stringWithFormat:@"¥ %@",_price];

    
}

//加入购物车
- (void) addInMarket {
    if (_addToMarket) {
        _addToMarket();
    }
}




/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
