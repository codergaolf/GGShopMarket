//
//  NSDictionary+Property.h
//  runtime(自动生成属性代码)
//
//  Created by 高立发 on 16/9/23.
//  Copyright © 2016年 GG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (Property)

- (void) creatPropertyCode;

@end
