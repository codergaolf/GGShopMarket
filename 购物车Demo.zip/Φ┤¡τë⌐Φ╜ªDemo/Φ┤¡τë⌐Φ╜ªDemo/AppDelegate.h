//
//  AppDelegate.h
//  购物车Demo
//
//  Created by 樊杨 on 2016/10/7.
//  Copyright © 2016年 fanyang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

