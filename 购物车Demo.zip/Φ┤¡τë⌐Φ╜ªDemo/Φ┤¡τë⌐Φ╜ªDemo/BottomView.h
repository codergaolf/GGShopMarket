//
//  BottomView.h
//  购物车Demo
//
//  Created by 高立发 on 2016/10/11.
//  Copyright © 2016年 fanyang. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ItemView.h"

@interface BottomView : UIView

#pragma mark =============== 存放规格view的数组, 用于到vc里面拿id和判断 ===============
//**  可变数组 */
@property (nonatomic, strong) NSMutableArray *itemsArr;

#pragma mark =============== 基本属性 ===============
//**  总价格 */
@property (nonatomic, copy) NSString *price;
//**  单价 */
@property (nonatomic, assign) CGFloat singlePrice;
//**  库存 */
@property (nonatomic, copy) NSString *goods_storage;
//**  总数量 */
@property (nonatomic, copy) NSString *count;

//**  中间的规格数组 */
@property (nonatomic, strong) NSArray *specInfoArray;

#pragma mark =============== UI相关 ===============
//**  图标 */
@property (nonatomic, strong) UIImageView *imageView;
//**  价格 */
@property (nonatomic, strong) UILabel *priceLb;
//**  库存 */
@property (nonatomic, strong) UILabel *inventoryLb;
//**  描述 */
@property (nonatomic, strong) UILabel *descLb;
//**  数量 */
@property (nonatomic, strong) UILabel *countLb;
//**  取消 */
@property (nonatomic, strong) UIButton *cancelBtn;
//**  购买数量 */
@property (nonatomic, strong) UILabel *buyCount;
//**  减少 */
@property (nonatomic, strong) UIButton *minusBtn;
//**  增加 */
@property (nonatomic, strong) UIButton *plusBtn;
//**  加入购物车 */
@property (nonatomic, strong) UIButton *marketBtn;

//**  类型较多的话有可能要用到的滚动 */
@property (nonatomic, strong) UIScrollView *scrollView;


#pragma mark =============== 点击事件 ===============
//**  取消block */
@property (nonatomic, copy) void (^cancel)();
//**  加入block */
@property (nonatomic, copy) void (^addToMarket)();
//**  所选数量超过内存 */
@property (nonatomic, copy) void (^alert)(NSString *alertString);

//**  selectBlock */
@property (nonatomic, copy) void (^selectBlock)(NSDictionary *dic);


@end
