//
//  ItemView.h
//  购物车Demo
//
//  Created by 高立发 on 2016/10/11.
//  Copyright © 2016年 fanyang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ItemView : UIView

//**  数据字典 */
@property (nonatomic, strong) NSDictionary *dataDic;

//**  标题 */
@property (nonatomic, strong) UILabel *titleLb;

//**  返回选择的类型 */
@property (nonatomic, copy) void (^selected)(NSDictionary *dic);

//**  给一个属性判断是否被点过这个属性 */
@property (nonatomic, assign) BOOL isSelected;

//**  干脆把选择了的这个标签对应的字典拿出来 */
@property (nonatomic, strong) NSDictionary *selectedDic;

//**  记录一下这个view需要用到的高度 */
@property (nonatomic, assign) CGFloat height;


- (instancetype) initWithDataDictionry: (NSDictionary *)dataDic;

@end
