//
//  ViewController.m
//  购物车Demo
//
//  Created by 高立发 on 2016/10/9.
//  Copyright © 2016年 fanyang. All rights reserved.
//

#define screen_width [UIScreen mainScreen].bounds.size.width
#define screen_height [UIScreen mainScreen].bounds.size.height

#import "ViewController.h"

#import "ShopViewController.h"

#import "BottomView.h"
#import "ItemView.h"

@interface ViewController ()<UIAlertViewDelegate>

{
    UIView *bigView;
    
}

//**  bottomView */
@property (nonatomic, strong) BottomView * bottomView;

//商品详情的code
@property(nonatomic,copy)NSString * code;

//添加购物车的code
@property(nonatomic,copy)NSString * cartCode;

@property(nonatomic,copy)NSString * goods_id;
//添加到购物车token
@property(nonatomic,copy)NSString * token;



//**  存放规格的数组 */
@property (nonatomic, strong) NSArray *spec_info_array;

//**  默认的规格 */
@property (nonatomic, strong) NSArray *goods_spec_array;

//**  用来获取加入购物车good_id的数组 */
@property (nonatomic, strong) NSArray *spec_list_array;

//**  dataDic */
@property (nonatomic, strong) NSDictionary *dataDic;

//**  goods_info_dic */
@property (nonatomic, strong) NSDictionary *goods_info_dic;


//**  dataModel */
@property (nonatomic, strong) DataModel *dataModel;
//**  goodInfo */
@property (nonatomic, strong) GoodInfo *goodInfo;

//**  bottomView的高度 */
@property (nonatomic, assign) CGFloat btHeight;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //** 不知道为什么就想放个图
    UIImageView *imageView = [[UIImageView alloc]init];
    imageView.backgroundColor = [UIColor orangeColor];
    [imageView sd_setImageWithURL:[NSURL URLWithString:@"http://b.hiphotos.baidu.com/image/pic/item/8d5494eef01f3a29b41f18fa9c25bc315c607c2b.jpg"] placeholderImage:nil completed:nil];
    [self.view addSubview:imageView];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).with.offset(100);
        make.centerX.equalTo(self.view);
        make.width.equalTo(@(150));
        make.height.equalTo(@(250));
    }];
    
    //添加购物车
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0,Screen_Height-60-49,Screen_Width, 60);
    [btn setTitle:@"加入购物车" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(ButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    btn.backgroundColor = [UIColor redColor];
    [self.view addSubview:btn];
    
    self.token = [NSString string];
    //数据请求
    [self loadData];
    
    
}

#pragma mark =============== 获取数据 ===============
-(void)loadData{
    
    
#pragma mark  -- 本地获取数据
    NSString *path = [[NSBundle mainBundle] pathForResource:@"goodInfo" ofType:@"plist"];
    NSDictionary *rootDic = [NSKeyedUnarchiver unarchiveObjectWithFile:path];
    
    _dataDic = rootDic[@"data"];
    
    _dataModel = [DataModel mj_objectWithKeyValues:_dataDic];
    _goodInfo = _dataModel.goods_info;
    
    _spec_list_array = _dataModel.spec_list;
    _spec_info_array = _goodInfo.spec_info;
    _goods_spec_array = _goodInfo.goods_spec;
    _code = @"200";
    
}

-(void)ButtonClick:(UIButton *)btn{
    
    if (_code.intValue == 200){
        
        __weak ViewController *weakSelf = self;
        
        if (bigView) {
            [bigView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
            [bigView removeFromSuperview];
        }
        if (_bottomView) {
            [_bottomView removeFromSuperview];
        }
        
        
        bigView=[[UIView alloc]initWithFrame:CGRectMake(0,0, screen_width, screen_height-49)];
        bigView.backgroundColor = [UIColor colorWithRed:0.3 green:0.3 blue:0.3 alpha:0.3];
        //给自己添加了一个点击手势, 移除这些view
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(removeInputTextView)];
        [bigView addGestureRecognizer:tapGesture];
        [self.view addSubview:bigView];
        
        
        _bottomView=[[BottomView alloc]init];
        
        //商品图片
        NSString *imageUrlString = [_dataModel.goods_image firstObject];
        [_bottomView.imageView sd_setImageWithURL:[NSURL URLWithString: imageUrlString] placeholderImage:nil completed:nil];
        
        //商品价格
        _bottomView.price = _goodInfo.goods_price;
        
        //商品库存
        _bottomView.goods_storage = _goodInfo.goods_storage;
        
        //超出看库存
        _bottomView.alert = ^(NSString *alertStr){
            UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"提示" message:alertStr delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alert show];
        };
        
        //商品的各种规格
        _bottomView.specInfoArray = _spec_info_array;
        
        if (_bottomView.scrollView.contentSize.height > 400) {
            _btHeight = 540.0;
            
        } else if (_bottomView.scrollView.contentSize.height < 150) {
            _btHeight = 310;
        } else {
            _btHeight = 140 + _bottomView.scrollView.contentSize.height + 20;
        }
        
        _bottomView.frame = CGRectMake(0, screen_height, screen_width, _btHeight);
        
        //右上角的X: 取消
        _bottomView.cancel = ^(){
            [weakSelf removeInputTextView];
        };
        
        //加入购物车
        _bottomView.addToMarket = ^(){
            NSMutableArray *keyArray = [[NSMutableArray alloc]init];
            
            //这里循环, 拿到所有选择的key, 如果有没选的, 提示一下用户
            for (ItemView *item in weakSelf.bottomView.itemsArr) {
                if (item.isSelected == NO) {
                    UIAlertView * success = [[UIAlertView alloc]initWithTitle:@"提示" message:[NSString stringWithFormat:@"请选择%@",item.titleLb.text] delegate:weakSelf cancelButtonTitle:@"确定" otherButtonTitles:nil];
                    
                    [success show];
                    
                    return ;
                    
                } else {
                    [keyArray addObject:item.selectedDic[@"key"]];
                }
            }
            
            [weakSelf addCartData:keyArray];
            
            
        };
        
        
        
        //选择这个block的主要目的
        //1> 是用来替换上面的图片
        //2> 更新上面的规格描述
        _bottomView.selectBlock = ^(NSDictionary *dic){
            NSMutableArray *valueArray = [[NSMutableArray alloc]init];
            NSMutableArray *unSelectedArray = [[NSMutableArray alloc]init];
            //这里循环, 拿到所有选择的key, 如果有没选的, 提示一下用户
            for (ItemView *item in weakSelf.bottomView.itemsArr) {
                if (item.isSelected == YES) {
                    [valueArray addObject:item.selectedDic[@"value"]];
                    
                } else {
                    [unSelectedArray addObject:item.titleLb.text];
                    
                }
            }
            
            //更改描述提示
            NSString *descString = [NSString string];
            if (unSelectedArray.count > 0) {
                descString = [NSString stringWithFormat:@"请选择 %@", [unSelectedArray componentsJoinedByString:@" "]];
            } else {
                descString = [valueArray componentsJoinedByString:@"  "];
                
            }
            weakSelf.bottomView.descLb.text = descString;

            
            //更换商品图片
            NSString *imgUrl = dic[@"image"];
            if (imgUrl.length > 1) {
                [weakSelf.bottomView.imageView sd_setImageWithURL:[NSURL URLWithString:imgUrl] placeholderImage:nil completed:nil];
            }
            
            UIAlertView * success = [[UIAlertView alloc]initWithTitle:[NSString stringWithFormat:@"name: %@", dic[@"value"]] message:[NSString stringWithFormat:@"\n-key: %@\n-value: %@\n img: %@", dic[@"key"], dic[@"value"], dic[@"image"]] delegate:weakSelf cancelButtonTitle:@"确定" otherButtonTitles:nil];
            
            [success show];
        };
        
        
        [self.view addSubview:_bottomView];//这个地方一定是加到self.view而不是bigView，否则bottomView会和bigView拥有一个手势。
        
        //动画效果
        [UIView animateWithDuration:0.8f
                         animations:^{
                             //设置_topView的frame
                             CGRect bottomViewFrame = _bottomView.frame;
                             bottomViewFrame.origin.y = screen_height-_btHeight-49;
                             [_bottomView setFrame:bottomViewFrame];
                         } completion:nil];
        
    }
    
}


//加入购物车
-(void)addCartData:(NSMutableArray *)keyArray{
    
    //拿到了key数组, 拼接字符串, 到对应数组里面找对应的参数good_id
    NSString *joinedString = [keyArray componentsJoinedByString:@"|"];
    for (NSDictionary *dic in _dataModel.spec_list) {
        if ([joinedString isEqualToString: dic[@"key"]]) {
            self.goods_id = dic[@"value"];
        }
    }
    
    NSLog(@"----就这-%@-个破玩意, 要老子-¥%@-块钱? ?---",_bottomView.count, _bottomView.price);
    
    NSDictionary * dic = @{@"goods_id":self.goods_id,@"quantity":_bottomView.count};
    
    NSLog(@"paraDic: %@", dic);
    
}


-(void)removeInputTextView
{
    [UIView animateWithDuration:0.8f
                     animations:^{
                         //设置_topView的frame
                         CGRect bottomViewFrame = _bottomView.frame;
                         bottomViewFrame.origin.y =screen_height;
                         [_bottomView setFrame:bottomViewFrame];
                     } completion:^(BOOL finished) {
                         bigView.hidden=YES;
                     }];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
