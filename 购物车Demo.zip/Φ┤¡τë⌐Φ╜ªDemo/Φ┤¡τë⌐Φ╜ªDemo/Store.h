//
//  Store.h
//  购物车Demo
//
//  Created by 高立发 on 2016/10/11.
//  Copyright © 2016年 fanyang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Store : NSObject


//**  记录段的选中状态 */
@property (nonatomic, assign) BOOL isSelected;

//**  店铺id */
@property (nonatomic, copy) NSString *store_id;
//**  店铺名字 */
@property (nonatomic, copy) NSString *store_name;
//**  店铺的数组 */
@property (nonatomic, strong) NSMutableArray *goodslist;

@end
