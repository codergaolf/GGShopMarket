//
//  GoodTableViewCell.h
//  购物车Demo
//
//  Created by 高立发 on 2016/10/12.
//  Copyright © 2016年 fanyang. All rights reserved.
//

#import <UIKit/UIKit.h>


#import "StoreGoodInfo.h"

@interface GoodTableViewCell : UITableViewCell

/*
 [contentView addSubview: btn];
 [contentView addSubview: imageView];
 [contentView addSubview: descLb];
 [contentView addSubview: typeLb];
 [contentView addSubview: singPriceLb];
 [contentView addSubview: countLb];
 [contentView addSubview: paddingView];
 */

//**  圈圈按钮 */
@property (nonatomic, strong) UIButton *btn;
//**  产品图 */
@property (nonatomic, strong) UIImageView *goodImageView;
//**  描述 */
@property (nonatomic, strong) UILabel *descLb;
//**  种类 */
@property (nonatomic, strong) UILabel *typeLb;
//**  单价 */
@property (nonatomic, strong) UILabel *singlePriceLb;
//**  数量 */
@property (nonatomic, strong) UILabel *countLb;
//**  下面画一条先 */
@property (nonatomic, strong) UIView *paddingView;

//**  点击圈圈的时间 */
@property (nonatomic, copy) void (^btClick)();


//**  给UI信息的model */
@property (nonatomic, strong) StoreGoodInfo *goodInfo;

- (instancetype) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier;


@end
