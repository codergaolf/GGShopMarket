//
//  StoreGoodInfo.h
//  购物车Demo
//
//  Created by 高立发 on 2016/10/11.
//  Copyright © 2016年 fanyang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StoreGoodInfo : NSObject

//**  记录是不是被选了 */
@property (nonatomic, assign) BOOL isSelected;


@property (nonatomic, copy) NSString *gc_id;

@property (nonatomic, copy) NSString *goods_commonid;

@property (nonatomic, copy) NSString *goods_click;

@property (nonatomic, copy) NSString *virtual_indate;

@property (nonatomic, copy) NSString *virtual_invalid_refund;

@property (nonatomic, copy) NSString *have_gift;

@property (nonatomic, copy) NSString *goods_freight;

@property (nonatomic, copy) NSString *gc_id_1;

@property (nonatomic, copy) NSString *cart_id;

@property (nonatomic, copy) NSString *goods_jingle;

@property (nonatomic, copy) NSString *areaid_2;

@property (nonatomic, copy) NSString *goods_vat;

@property (nonatomic, copy) NSString *is_appoint;

@property (nonatomic, copy) NSString *goods_commend;

@property (nonatomic, copy) NSString *is_fcode;

@property (nonatomic, copy) NSString *brand_id;

@property (nonatomic, copy) NSString *is_virtual;

@property (nonatomic, copy) NSString *goods_addtime;

@property (nonatomic, copy) NSString *goods_price;

@property (nonatomic, copy) NSString *evaluation_good_star;

@property (nonatomic, copy) NSString *goods_storage;

@property (nonatomic, copy) NSString *goods_state;

@property (nonatomic, copy) NSString *virtual_limit;

@property (nonatomic, copy) NSString *evaluation_count;

@property (nonatomic, copy) NSString *color_id;

@property (nonatomic, copy) NSString *areaid_1;

@property (nonatomic, copy) NSString *goods_image_url;

@property (nonatomic, copy) NSString *goods_promotion_type;

@property (nonatomic, copy) NSString *store_name;

@property (nonatomic, copy) NSString *goods_collect;

@property (nonatomic, copy) NSString *is_presell;

//(null)

@property (nonatomic, copy) NSString *goods_id;

@property (nonatomic, copy) NSString *goods_promotion_price;

@property (nonatomic, copy) NSString *goods_image;

//(null)

@property (nonatomic, copy) NSString *goods_name;

@property (nonatomic, copy) NSString *is_own_shop;

@property (nonatomic, copy) NSString *goods_num;

@property (nonatomic, strong) NSArray *goods_spec;

@property (nonatomic, copy) NSString *gc_id_3;

@property (nonatomic, copy) NSString *store_id;

@property (nonatomic, copy) NSString *goods_serial;

@property (nonatomic, copy) NSString *transport_id;

@property (nonatomic, copy) NSString *goods_edittime;

@property (nonatomic, copy) NSString *goods_salenum;

@property (nonatomic, copy) NSString *gc_id_2;

@property (nonatomic, copy) NSString *goods_verify;

@property (nonatomic, copy) NSString *goods_storage_alarm;

@property (nonatomic, copy) NSString *goods_stcids;

@property (nonatomic, copy) NSString *goods_marketprice;

@end
