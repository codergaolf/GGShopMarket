//
//  DataModel.h
//  购物车Demo
//
//  Created by 高立发 on 2016/10/11.
//  Copyright © 2016年 fanyang. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "GoodInfo.h"

@interface DataModel : NSObject

@property (nonatomic, strong) NSArray *gift_array;

@property (nonatomic, strong) NSDictionary *store_info;

@property (nonatomic, strong) GoodInfo *goods_info;

@property (nonatomic, strong) NSDictionary *mansong_info;

@property (nonatomic, strong) NSArray *goods_image;

@property (nonatomic, strong) NSArray *goods_commend_list;

@property (nonatomic, strong) NSArray *goods_eval_list;

@property (nonatomic, strong) NSDictionary *goods_hair_info;

@property (nonatomic, strong) NSDictionary *goods_evaluate_info;

@property (nonatomic, strong) NSArray *spec_list;

@end
