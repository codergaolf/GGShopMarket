//
//  GoodTableViewCell.m
//  购物车Demo
//
//  Created by 高立发 on 2016/10/12.
//  Copyright © 2016年 fanyang. All rights reserved.
//

#import "GoodTableViewCell.h"

@implementation GoodTableViewCell

- (instancetype) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (!self) {
        return nil;
    }
    
    //给个背景颜色
    self.backgroundColor = [UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1.0];
    
    //contentView
    UIView *contentView = self.contentView;
    
    //圆圈按钮
    _btn = [self creatBtn:@selector(buttonClick:)];
    
    //产品图片
    _goodImageView = [[UIImageView alloc] initWithFrame:CGRectZero];
    
    //描述
    _descLb = [[UILabel alloc] init];
    _descLb.numberOfLines = 2;
    _descLb.font = [UIFont systemFontOfSize:15.0];
    
    //型号
    _typeLb = [[UILabel alloc] init];
    _typeLb.font = [UIFont systemFontOfSize:14.0];
    
    //单价
    _singlePriceLb = [[UILabel alloc]init];
    _singlePriceLb.font = [UIFont systemFontOfSize:15.0];
    _singlePriceLb.textColor = [UIColor redColor];
    
    //数量
    _countLb = [[UILabel alloc]init];
    _countLb.font = [UIFont systemFontOfSize:14.0];
    
    //底下划一根线
    _paddingView = [[UIView alloc]initWithFrame:CGRectZero];
    _paddingView.backgroundColor = [UIColor grayColor];
    
    //加到cell图上
    [contentView addSubview: _btn];
    [contentView addSubview: _goodImageView];
    [contentView addSubview: _descLb];
    [contentView addSubview: _typeLb];
    [contentView addSubview: _singlePriceLb];
    [contentView addSubview: _countLb];
    [contentView addSubview: _paddingView];
    
    
    
    
    return self;
}

- (void) setGoodInfo:(StoreGoodInfo *)goodInfo
{
    _goodInfo = goodInfo;
    
    //1,给图
    [_goodImageView sd_setImageWithURL:[NSURL URLWithString:goodInfo.goods_image_url]];
    
    //2,描述
    _descLb.text = goodInfo.goods_name;
    
    //3,规格
    NSArray *goods_spec_array = goodInfo.goods_spec;
    NSMutableArray *typeArr = [[NSMutableArray alloc]init];
    for (NSDictionary *typeDic in goods_spec_array) {
        [typeArr addObject: typeDic[@"value"]];
    }
    _typeLb.text = [typeArr componentsJoinedByString:@" "];
    
    //4,单价
    _singlePriceLb.text = goodInfo.goods_price;
    
    //5,数量
    _countLb.text = [NSString stringWithFormat:@"x %@", goodInfo.goods_num];
    
    //6,按钮选中状态
    if (goodInfo.isSelected == YES) {
        _btn.selected = YES;
        [self.btn setBackgroundColor:[UIColor redColor]];
    } else {
        _btn.selected = NO;
        [self.btn setBackgroundColor:[UIColor whiteColor]];
    }
}

- (void) layoutSubviews
{
    
    //contentView
    UIView *contentView = self.contentView;
    
    [_btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(contentView);
        make.left.equalTo(contentView).with.offset(10);
        make.width.height.equalTo(@(20));
    }];
    
    [_goodImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_btn.mas_right).with.offset(10);
        make.top.equalTo(contentView).with.offset(10);
        make.width.height.equalTo(@(100));
    }];
    
    [_descLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_goodImageView.mas_right).with.offset(10);
        make.right.equalTo(contentView).with.offset(-10);
        make.top.equalTo(contentView).with.offset(15);
    }];
    
    [_typeLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_descLb);
        make.right.equalTo(_descLb);
        make.top.equalTo(_descLb.mas_bottom).with.offset(5);
    }];
    
    [_singlePriceLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_descLb);
        make.height.equalTo(@(20));
        make.top.equalTo(_typeLb.mas_bottom).with.offset(5);
    }];
    
    [_countLb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_singlePriceLb.mas_right).with.offset(10);
        make.centerY.equalTo(_singlePriceLb);
        make.height.equalTo(_singlePriceLb);
    }];
    
    [_paddingView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(contentView);
        make.height.equalTo(@(0.5));
    }];
   
}
//创建圈圈按钮
- (UIButton *) creatBtn: (SEL) selectSec {
    //圆圈按钮
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.layer.masksToBounds = YES;
    btn.layer.cornerRadius = 10.0;
    btn.layer.borderWidth = 2.0;
    btn.layer.borderColor = [[UIColor grayColor]CGColor];
    [btn setBackgroundColor:[UIColor whiteColor]];
    [btn addTarget:self action:selectSec forControlEvents:UIControlEventTouchUpInside];
    return btn;
}

//点击事件
- (void) buttonClick: (UIButton *) btn
{
    
    //改变选中状态
    btn.selected = !btn.selected;
    
    //调整UI
    if (btn.selected == YES) {
        [btn setBackgroundColor: [UIColor redColor]];
    } else {
        [btn setBackgroundColor: [UIColor whiteColor]];
    }
    
    if (_btClick) {
        _btClick();
    }
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end



/*
 NSInteger section = indexPath.section;
 NSInteger row = indexPath.row;
 static NSString *cellID = @"cellID";
 UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
 if (!cell) {
 cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
 }
 StoreGoodInfo *goodInfo = self.dataArray[section][row];
 
 //给个背景颜色
 cell.backgroundColor = [UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1.0];
 
 //contentView
 UIView *contentView = cell.contentView;
 
 //先删除后添加
 [contentView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
 
 //圆圈按钮
 UIButton *btn = [self creatBtn:@selector(selectSection:)];
 btn.tag = 2000 + row;
 
 //产品图片
 UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectZero];
 [imageView sd_setImageWithURL:[NSURL URLWithString:goodInfo.goods_image_url]];
 
 //描述
 UILabel *descLb = [[UILabel alloc] init];
 descLb.numberOfLines = 2;
 descLb.font = [UIFont systemFontOfSize:15.0];
 descLb.text = goodInfo.goods_name;
 
 //型号
 UILabel *typeLb = [[UILabel alloc] init];
 typeLb.font = [UIFont systemFontOfSize:14.0];
 NSArray *goods_spec_array = goodInfo.goods_spec;
 NSMutableArray *typeArr = [[NSMutableArray alloc]init];
 for (NSDictionary *typeDic in goods_spec_array) {
 [typeArr addObject: typeDic[@"value"]];
 }
 typeLb.text = [typeArr componentsJoinedByString:@" "];
 
 //单价
 UILabel *singPriceLb = [[UILabel alloc]init];
 singPriceLb.font = [UIFont systemFontOfSize:15.0];
 singPriceLb.text = goodInfo.goods_price;
 singPriceLb.textColor = [UIColor redColor];
 
 //数量
 UILabel *countLb = [[UILabel alloc]init];
 countLb.font = [UIFont systemFontOfSize:14.0];
 countLb.text = [NSString stringWithFormat:@"x %@", goodInfo.goods_num];
 
 //底下划一根线
 UIView *paddingView = [[UIView alloc]initWithFrame:CGRectZero];
 paddingView.backgroundColor = [UIColor grayColor];
 
 //加到cell图上
 [contentView addSubview: btn];
 [contentView addSubview: imageView];
 [contentView addSubview: descLb];
 [contentView addSubview: typeLb];
 [contentView addSubview: singPriceLb];
 [contentView addSubview: countLb];
 [contentView addSubview: paddingView];
 
 
 [btn mas_makeConstraints:^(MASConstraintMaker *make) {
 make.centerY.equalTo(contentView);
 make.left.equalTo(contentView).with.offset(10);
 make.width.height.equalTo(@(20));
 }];
 
 [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
 make.left.equalTo(btn.mas_right).with.offset(10);
 make.top.equalTo(contentView).with.offset(10);
 make.width.height.equalTo(@(100));
 }];
 
 [descLb mas_makeConstraints:^(MASConstraintMaker *make) {
 make.left.equalTo(imageView.mas_right).with.offset(10);
 make.right.equalTo(contentView).with.offset(-10);
 make.top.equalTo(contentView).with.offset(15);
 }];
 
 [typeLb mas_makeConstraints:^(MASConstraintMaker *make) {
 make.left.equalTo(descLb);
 make.right.equalTo(descLb);
 make.top.equalTo(descLb.mas_bottom).with.offset(5);
 }];
 
 [singPriceLb mas_makeConstraints:^(MASConstraintMaker *make) {
 make.left.equalTo(descLb);
 make.height.equalTo(@(20));
 make.top.equalTo(typeLb.mas_bottom).with.offset(5);
 }];
 
 [countLb mas_makeConstraints:^(MASConstraintMaker *make) {
 make.left.equalTo(singPriceLb.mas_right).with.offset(10);
 make.centerY.equalTo(singPriceLb);
 make.height.equalTo(singPriceLb);
 }];
 
 [paddingView mas_makeConstraints:^(MASConstraintMaker *make) {
 make.left.right.bottom.equalTo(contentView);
 make.height.equalTo(@(0.5));
 }];
 */
