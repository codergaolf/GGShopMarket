

//加入购物车时用到的数据


{
    "result": 0,
    "code": 200,
    "data": {
        "goods_info": {
            "goods_name": "\u7eb1\u79cb\u8863 \u6591\u70b9 L",
            "goods_jingle": "\u4f11\u95f2\u4e1d\u9762\u6599",
            "gc_id_1": "256",
            "gc_id_2": "259",
            "gc_id_3": "1855",
            "goods_attr": [
                           {
                               "name": "\u8896\u957f",
                               "value": "\u4e0d\u9650"
                           },
                           {
                               "name": "\u670d\u88c5\u7248\u578b",
                               "value": "\u4e0d\u9650"
                           },
                           {
                               "name": "\u8863\u957f",
                               "value": "\u4e0d\u9650"
                           },
                           {
                               "name": "\u9886\u578b",
                               "value": "\u4e0d\u9650"
                           },
                           {
                               "name": "\u8896\u578b",
                               "value": "\u4e0d\u9650"
                           },
                           {
                               "name": "\u6210\u5206\u542b\u91cf",
                               "value": "\u4e0d\u9650"
                           },
                           {
                               "name": "\u9762\u6599",
                               "value": "\u4e0d\u9650"
                           },
                           {
                               "name": "\u56fe\u6848\u6587\u5316",
                               "value": "\u4e0d\u9650"
                           },
                           {
                               "name": "\u9002\u7528\u5e74\u9f84",
                               "value": "\u4e0d\u9650"
                           },
                           {
                               "name": "\u98ce\u683c",
                               "value": "\u4e0d\u9650"
                           },
                           {
                               "name": "\u5e74\u4efd\u5b63\u8282",
                               "value": "\u4e0d\u9650"
                           }
                           ],
            "goods_keywords": "",
            "goods_description": "",
            "mobile_body": "",
            "goods_state": "1",
            "goods_specname": "",
            "goods_price": "100.00",
            "goods_marketprice": "210.00",
            "goods_costprice": "0.00",
            "goods_discount": "47",
            "goods_serial": "",
            "goods_storage_alarm": "0",
            "transport_id": "62",
            "transport_title": "\u547c\u548c\u6d69\u7279\u514d\u8fd0\u8d39",
            "goods_freight": "0.00",
            "goods_vat": "0",
            "areaid_1": "5",
            "areaid_2": "95",
            "goods_stcids": "",
            "plateid_top": "0",
            "plateid_bottom": "0",
            "is_virtual": "0",
            "virtual_indate": "0",
            "virtual_limit": "0",
            "virtual_invalid_refund": "0",
            "is_fcode": "0",
            "is_appoint": "0",
            "appoint_satedate": "0",
            "is_presell": "0",
            "presell_deliverdate": "0",
            "is_own_shop": "0",
            "transport_type": "7",
            "is_support_return": "1",
            "goods_id": "137019",
            "goods_promotion_price": "100.00",
            "goods_promotion_type": "0",
            "goods_click": 407,
            "goods_salenum": "0",
            "goods_collect": "0",
            "goods_spec": [
                           {
                               "key": 10377,
                               "value": "\u6591\u70b9"
                           },
                           {
                               "key": 10444,
                               "value": "L"
                           }
                           ],
            "goods_storage": "5",
            "color_id": "10377",
            "evaluation_good_star": "5",
            "evaluation_count": "0",
            "have_gift": "0",
            "groupbuy_info": null,
            "xianshi_info": null,
            "cart": true,
            "goods_url": "http:\/\/www.jingouwang.cn\/shop\/index.php?act=goods&op=index&goods_id=137019",
            "spec_info": [
                          {
                              "specid": 1,
                              "name": "\u989c\u8272",
                              "speclist": [
                                           {
                                               "key": 10377,
                                               "value": "\u6591\u70b9",
                                               "image": "http:\/\/42.123.82.237:18082\/upload\/shop\/store\/goods\/313\/313_05294052984140726_60.jpg"
                                           }
                                           ]
                          },
                          {
                              "specid": 15,
                              "name": "\u5c3a\u7801",
                              "speclist": [
                                           {
                                               "key": 10444,
                                               "value": "L",
                                               "image": ""
                                           },
                                           {
                                               "key": 10445,
                                               "value": "XL",
                                               "image": ""
                                           },
                                           {
                                               "key": 10446,
                                               "value": "XXL",
                                               "image": ""
                                           }
                                           ]
                          }
                          ]
        },
        "mansong_info": null,
        "gift_array": [
        
        ],
        "goods_commend_list": [
                               {
                                   "goods_id": "136917",
                                   "goods_name": "\u54aa\u8482\u59ae\u5939\u514b \u7ea2\u8272 L",
                                   "goods_price": null,
                                   "goods_promotion_price": "160.00",
                                   "goods_image_url": "http:\/\/42.123.82.237:18082\/upload\/shop\/store\/goods\/313\/313_05291753735032166_240.jpg"
                               },
                               {
                                   "goods_id": "104018",
                                   "goods_name": "2016\u5e74\u65b0\u6b3e\u5973\u88c5\u8fde\u8863\u88d9  \u7f8e\u7490\u65f6\u5c1a\u82b1\u8fde\u8863\u88d9 \u5973\u88c5\u96ea\u7eba\u8fde\u8863\u88d9 \u4e2d\u957f\u6b3e\u4fee\u8eab\u5927\u7801\u6c14\u8d28\u5370\u82b1\u77ed\u8896\u88d9\u5b50 \u7eff\u8272 ",
                                   "goods_price": null,
                                   "goods_promotion_price": "238.00",
                                   "goods_image_url": "http:\/\/42.123.82.237:18082\/upload\/shop\/store\/goods\/313\/313_05248553695151697_240.jpg"
                               },
                               {
                                   "goods_id": "136786",
                                   "goods_name": "\u5e03\u7f8e\u98ce\u8863 \u85cf\u9752\u8272 M",
                                   "goods_price": null,
                                   "goods_promotion_price": "310.00",
                                   "goods_image_url": "http:\/\/42.123.82.237:18082\/upload\/shop\/store\/goods\/313\/313_05291668497726302_240.jpg"
                               }
                               ],
        "store_info": {
            "store_id": "313",
            "store_name": "\u8d1d\u7426\u5973\u88c5",
            "member_id": "379",
            "member_name": "\u8d1d\u7426\u5973\u88c5",
            "is_own_shop": "0",
            "store_phone": "18686013357",
            "goods_count": "44",
            "store_credit": {
                "store_desccredit": {
                    "text": "\u63cf\u8ff0\u76f8\u7b26",
                    "credit": 5,
                    "percent": "----",
                    "percent_class": "equal",
                    "percent_text": "\u5e73"
                },
                "store_servicecredit": {
                    "text": "\u670d\u52a1\u6001\u5ea6",
                    "credit": 5,
                    "percent": "----",
                    "percent_class": "equal",
                    "percent_text": "\u5e73"
                },
                "store_deliverycredit": {
                    "text": "\u53d1\u8d27\u901f\u5ea6",
                    "credit": 5,
                    "percent": "----",
                    "percent_class": "equal",
                    "percent_text": "\u5e73"
                }
            }
        },
        "spec_list": [
                      {
                          "key": "10377|10444",
                          "value": "137019"
                      },
                      {
                          "key": "10377|10445",
                          "value": "137020"
                      },
                      {
                          "key": "10377|10446",
                          "value": "137021"
                      }
                      ],
        "goods_image": [
                        "http:\/\/42.123.82.237:18082\/upload\/shop\/store\/goods\/313\/313_05294052984140726_360.jpg",
                        "http:\/\/42.123.82.237:18082\/upload\/shop\/store\/goods\/313\/313_05294053341492396_360.jpg"
                        ],
        "goods_eval_list": [
        
        ],
        "goods_evaluate_info": {
            "good": 0,
            "normal": 0,
            "bad": 0,
            "all": 0,
            "good_percent": 100,
            "normal_percent": 0,
            "bad_percent": 0,
            "good_star": 5,
            "star_average": 5
        },
        "goods_hair_info": {
            "content": "\u514d\u8fd0\u8d39",
            "if_store_cn": "\u6709\u8d27",
            "if_store": true,
            "area_name": "\u5168\u56fd"
        }
    }
}

